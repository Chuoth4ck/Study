/**
 * Backend Trung Gian (Proxy Server) cho StudyAI Floating.
 * Giúp bảo vệ API Key (Gemini / OpenAI) trên máy chủ, không nhúng trực tiếp vào APK.
 * Chạy bằng lệnh: GEMINI_API_KEY="your_key" PORT=8080 node server.js
 */
const http = require('http');
const https = require('https');

const PORT = process.env.PORT || 8080;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const DEFAULT_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

function callGeminiUpstream(promptText, modelName) {
  return new Promise((resolve, reject) => {
    if (!GEMINI_API_KEY) {
      return reject(new Error('Máy chủ Proxy chưa được cấu hình biến môi trường GEMINI_API_KEY.'));
    }
    const model = modelName || DEFAULT_MODEL;
    const payload = JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: promptText }] }],
      generationConfig: {
        temperature: 0.2,
        responseMimeType: 'application/json'
      }
    });

    const options = {
      hostname: 'generativelanguage.googleapis.com',
      path: `/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      },
      timeout: 25000
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(body);
        } else {
          reject(new Error(`Upstream AI HTTP ${res.statusCode}`));
        }
      });
    });

    req.on('error', (err) => reject(err));
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Upstream AI request timeout'));
    });
    req.write(payload);
    req.end();
  });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200);
    return res.end(JSON.stringify({ status: 'ok', service: 'StudyAI-Floating-Proxy' }));
  }

  if (req.method === 'POST' && req.url === '/api/v1/solve') {
    let rawBody = '';
    req.on('data', (chunk) => {
      rawBody += chunk;
      if (rawBody.length > 2 * 1024 * 1024) req.destroy();
    });
    req.on('end', async () => {
      try {
        const parsed = JSON.parse(rawBody || '{}');
        const prompt = (parsed.prompt || '').trim();
        if (!prompt) {
          res.writeHead(400);
          return res.end(JSON.stringify({ error: 'Thiếu nội dung prompt câu hỏi.' }));
        }
        const upstreamRaw = await callGeminiUpstream(prompt, parsed.model);
        res.writeHead(200);
        return res.end(upstreamRaw);
      } catch (err) {
        res.writeHead(502);
        return res.end(JSON.stringify({ error: err.message || 'Lỗi xử lý tại Backend Proxy.' }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end(JSON.stringify({ error: 'Không tìm thấy đường dẫn API.' }));
});

server.listen(PORT, () => {
  console.log(`StudyAI Floating Backend Proxy đang chạy tại cổng ${PORT}`);
});
