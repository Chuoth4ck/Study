# StudyAI Floating — Trợ lý giải bài tập AI trên mọi ứng dụng (Android)

Ứng dụng Android native (**Kotlin + XML Material 3 + Room SQLite + ML Kit OCR + OkHttp3 Coroutines**) được thiết kế tối ưu cho học sinh THCS & THPT tại Việt Nam (đặc biệt là chương trình GDPT 2018 Lớp 10) và tối ưu hóa sâu cho thiết bị cấu hình phổ thông như **OPPO A18 (RAM 4 GB / ROM 64 GB, màn hình HD+)**.

## 1. Cấu trúc thư mục dự án

```text
StudyAIFloating/
├── build.gradle.kts                     # Cấu hình Gradle gốc (AGP 8.3.2, Kotlin 1.9.23, KSP)
├── settings.gradle.kts                  # Khai báo module :app
├── gradle.properties                    # Bật R8 Full Mode, AndroidX, tối ưu bộ nhớ JVM
├── backend-proxy/                       # Máy chủ trung gian (Node.js) bảo vệ API Key trên server
│   ├── package.json
│   └── server.js
└── app/
    ├── build.gradle.kts                 # Cấu hình minSdk 26, targetSdk 34, Room, ML Kit, Security Crypto
    ├── proguard-rules.pro               # Quy tắc rút gọn mã R8/ProGuard và ẩn log debug
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml      # Khai báo quyền SYSTEM_ALERT_WINDOW, FGS, MediaProjection, Share
        │   ├── java/vn/edu/studyai/floating/
        │   │   ├── StudyAiApplication.kt
        │   │   ├── ai/                  # AiPromptBuilder, AiResponseParser, MultiProviderAiClient
        │   │   ├── capture/             # MediaProjectionHelper, ScreenCapturePermissionActivity
        │   │   ├── data/local/          # HomeworkEntity, HomeworkDao, AppDatabase, HistoryRepository
        │   │   ├── model/               # SchoolSubject (10 môn), QuestionType, StructuredSolution
        │   │   ├── ocr/                 # BitmapMemoryOptimizer (chống tràn RAM), OcrProcessor
        │   │   ├── overlay/             # FloatingSolverService (Nút nổi & Cửa sổ giải bài nổi)
        │   │   ├── security/            # SecureConfigManager (EncryptedSharedPreferences AES-256-GCM)
        │   │   └── ui/                  # MainActivity, ShareReceiverActivity, HistoryAdapter
        │   └── res/                     # Giao diện Tiếng Việt, Chủ đề Sáng/Tối (Xanh dương đậm & Tím)
        └── test/java/vn/edu/studyai/floating/
            └── StudyAiCoreLogicTest.kt  # Bộ kiểm thử đơn vị JUnit 4
```

## 2. Hướng dẫn biên dịch ra file APK cài đặt được

1. **Mở bằng Android Studio (Khuyên dùng)**:
   - Cài đặt **Android Studio Iguana (2023.2.1)** hoặc mới hơn (đi kèm JDK 17 và Android SDK 34).
   - Chọn **Open** -> Trỏ tới thư mục `StudyAIFloating`.
   - Đợi Gradle đồng bộ xong, vào menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - File APK xuất ra tại: `app/build/outputs/apk/debug/app-debug.apk`.
2. **Biên dịch bằng dòng lệnh (CLI) & Ký APK Release**:
   ```bash
   # Xuất APK Debug cài đặt nhanh để kiểm thử:
   ./gradlew assembleDebug

   # Tạo Keystore để ký APK Release:
   keytool -genkey -v -keystore studyai-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias studyai

   # Xuất APK Release đã tối ưu R8 (nhẹ ~6-8 MB cho OPPO A18):
   ./gradlew assembleRelease

   # Căn chỉnh (zipalign) và ký số bằng apksigner:
   zipalign -v -p 4 app/build/outputs/apk/release/app-release-unsigned.apk app-release-aligned.apk
   apksigner sign --ks studyai-release-key.jks --out StudyAIFloating-v1.0.0-release.apk app-release-aligned.apk
   apksigner verify StudyAIFloating-v1.0.0-release.apk
   ```

## 3. Hướng dẫn cấu hình AI API & Backend Proxy

- **Cách 1: Sử dụng Backend Proxy trung gian (Khuyên dùng để không lưu API Key trên điện thoại)**
  1. Trên máy chủ hoặc VPS/Cloud Run/Render, vào thư mục `backend-proxy/` và chạy:
     ```bash
     GEMINI_API_KEY="AIzaSy..." PORT=8080 node server.js
     ```
  2. Mở ứng dụng **StudyAI Floating** -> Bấm **Cấu hình AI** -> Chọn **Backend Trung Gian** -> Nhập URL HTTPS của máy chủ (ví dụ `https://studyai-proxy.yourdomain.com/api/v1/solve`) -> Bấm **Lưu cấu hình**.
- **Cách 2: Sử dụng trực tiếp Google Gemini API hoặc OpenAI-Compatible API**
  1. Mở ứng dụng -> Bấm **Cấu hình AI**.
  2. Chọn **Google Gemini API Chính thức** (mặc định model `gemini-2.5-flash`) hoặc **OpenAI / Tương thích OpenAI API** (`gpt-4o-mini`).
  3. Dán API Key cá nhân vào ô khóa bí mật (được mã hóa bằng `EncryptedSharedPreferences` AES-256-GCM trong Android Keystore) -> Bấm **Lưu cấu hình**.
