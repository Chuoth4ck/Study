plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "vn.edu.studyai.floating"
    compileSdk = 34

    defaultConfig {
        applicationId = "vn.edu.studyai.floating"
        minSdk = 26 // Android 8.0+ (Hỗ trợ TYPE_APPLICATION_OVERLAY chuẩn và OPPO A18)
        targetSdk = 34 // Android 14 ổn định theo chuẩn phát hành hiện hành
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Chỉ giữ tài nguyên ngôn ngữ Tiếng Việt để giảm dung lượng APK trên thiết bị 4GB RAM / 64GB ROM
        resourceConfigurations += listOf("vi")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // AndroidX Core & UI nhẹ (Ưu tiên XML Views + Material 3 để tiết kiệm RAM cho cửa sổ nổi trên OPPO A18)
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.activity:activity-ktx:1.8.2")

    // Coroutines cho tác vụ mạng và OCR chạy nền không gây treo UI
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // Room SQLite lưu lịch sử câu hỏi cục bộ nhẹ và hỗ trợ tìm kiếm nhanh
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // ML Kit Text Recognition (Latin/Vietnamese script) cho OCR ngoại tuyến nhẹ trên thiết bị
    implementation("com.google.mlkit:text-recognition:16.0.0")

    // Mạng HTTPS với OkHttp3 (nhẹ, kiểm soát timeout, retry và TLS chặt chẽ)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Lưu trữ cấu hình và API key mã hóa an toàn qua Android Keystore (AES-256-GCM)
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Kiểm thử đơn vị (Unit Testing)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
