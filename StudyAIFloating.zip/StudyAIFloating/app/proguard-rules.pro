# Giữ các thực thể Room Database
-keep class vn.edu.studyai.floating.data.local.** { *; }
-keep class vn.edu.studyai.floating.model.** { *; }

# Bảo vệ OkHttp & ML Kit
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class com.google.mlkit.** { *; }

# Loại bỏ log debug trong bản Release để tăng tốc độ và bảo mật
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
}
