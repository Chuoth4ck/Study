package vn.edu.studyai.floating

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import vn.edu.studyai.floating.security.SecureConfigManager
import java.io.File

class StudyAiApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        val configManager = SecureConfigManager(this)
        // Áp dụng giao diện Sáng / Tối đã lưu (mặc định theo hệ thống)
        AppCompatDelegate.setDefaultNightMode(configManager.getSavedNightMode())

        createFloatingNotificationChannel()
        cleanupTemporaryImages()
    }

    private fun createFloatingNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                FLOATING_CHANNEL_ID,
                "Trợ lý nút nổi StudyAI",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Hiển thị trạng thái hoạt động của nút nổi giải bài tập StudyAI"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    /**
     * Bảo mật & Quyền riêng tư: Xóa toàn bộ ảnh chụp bài tập tạm thời trong bộ nhớ đệm
     * khi khởi động ứng dụng, không lưu ảnh nhạy cảm lâu hơn cần thiết.
     */
    fun cleanupTemporaryImages() {
        try {
            val captureDir = File(cacheDir, "camera_captures")
            if (captureDir.exists() && captureDir.isDirectory) {
                captureDir.listFiles()?.forEach { file ->
                    runCatching { file.delete() }
                }
            }
        } catch (_: Exception) {
            // Bỏ qua lỗi xóa file tạm không quan trọng
        }
    }

    companion object {
        const val FLOATING_CHANNEL_ID = "studyai_floating_channel"
    }
}
