package vn.edu.studyai.floating.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import vn.edu.studyai.floating.R
import vn.edu.studyai.floating.data.local.HomeworkEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryAdapter(
    private val onItemClick: (HomeworkEntity) -> Unit,
    private val onDeleteClick: (HomeworkEntity) -> Unit
) : ListAdapter<HomeworkEntity, HistoryAdapter.HistoryViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history_question, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvSubject: TextView = itemView.findViewById(R.id.tvItemSubject)
        private val tvTimestamp: TextView = itemView.findViewById(R.id.tvItemTimestamp)
        private val tvQuestion: TextView = itemView.findViewById(R.id.tvItemQuestion)
        private val tvFinalAnswer: TextView = itemView.findViewById(R.id.tvItemFinalAnswer)
        private val btnDelete: Button = itemView.findViewById(R.id.btnDeleteHistoryItem)

        fun bind(item: HomeworkEntity) {
            val formatter = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            tvSubject.text = "${item.subjectName} • ${item.questionType}"
            tvTimestamp.text = formatter.format(Date(item.createdAtEpochMs))
            tvQuestion.text = item.recognizedProblem
            tvFinalAnswer.text = "Đáp án: ${item.finalAnswer}"

            itemView.setOnClickListener { onItemClick(item) }
            btnDelete.setOnClickListener { onDeleteClick(item) }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<HomeworkEntity>() {
            override fun areItemsTheSame(oldItem: HomeworkEntity, newItem: HomeworkEntity): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: HomeworkEntity, newItem: HomeworkEntity): Boolean {
                return oldItem == newItem
            }
        }
    }
}
