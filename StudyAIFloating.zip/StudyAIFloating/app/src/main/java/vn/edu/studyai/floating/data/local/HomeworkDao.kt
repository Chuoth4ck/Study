package vn.edu.studyai.floating.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface HomeworkDao {

    @Query("SELECT * FROM homework_history ORDER BY createdAtEpochMs DESC LIMIT 100")
    suspend fun getAllRecent(): List<HomeworkEntity>

    @Query(
        """
        SELECT * FROM homework_history
        WHERE recognizedProblem LIKE '%' || :keyword || '%'
           OR finalAnswer LIKE '%' || :keyword || '%'
           OR subjectName LIKE '%' || :keyword || '%'
        ORDER BY createdAtEpochMs DESC
        LIMIT 100
        """
    )
    suspend fun searchHistory(keyword: String): List<HomeworkEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(entity: HomeworkEntity): Long

    @Query("DELETE FROM homework_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM homework_history")
    suspend fun clearAllHistory()

    @Query("SELECT COUNT(*) FROM homework_history")
    suspend fun countHistoryItems(): Int
}
