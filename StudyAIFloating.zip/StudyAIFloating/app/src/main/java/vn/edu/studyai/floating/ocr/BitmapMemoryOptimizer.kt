package vn.edu.studyai.floating.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri

/**
 * Chuyên gia tối ưu hiệu năng cho thiết bị RAM 4GB (như OPPO A18):
 * Giảm kích thước ảnh (Downsampling) trước khi nạp vào RAM để tránh lỗi OutOfMemoryError.
 */
object BitmapMemoryOptimizer {

    private const val MAX_OCR_DIMENSION_PX = 1280

    fun calculateInSampleSize(rawWidth: Int, rawHeight: Int, maxDimension: Int = MAX_OCR_DIMENSION_PX): Int {
        var inSampleSize = 1
        if (rawHeight > maxDimension || rawWidth > maxDimension) {
            val halfHeight = rawHeight / 2
            val halfWidth = rawWidth / 2
            while ((halfHeight / inSampleSize) >= maxDimension || (halfWidth / inSampleSize) >= maxDimension) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    fun decodeSampledBitmapFromUri(context: Context, imageUri: Uri): Bitmap? {
        val boundsOptions = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        context.contentResolver.openInputStream(imageUri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOptions)
        }
        if (boundsOptions.outWidth <= 0 || boundsOptions.outHeight <= 0) {
            return null
        }

        val sampleSize = calculateInSampleSize(
            boundsOptions.outWidth,
            boundsOptions.outHeight,
            MAX_OCR_DIMENSION_PX
        )
        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            // Sử dụng ARGB_8888 đã thu nhỏ kích thước để ML Kit nhận dạng dấu tiếng Việt chính xác
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return context.contentResolver.openInputStream(imageUri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOptions)
        }
    }
}
