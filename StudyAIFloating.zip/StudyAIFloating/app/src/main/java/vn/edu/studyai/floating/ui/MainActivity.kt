package vn.edu.studyai.floating.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch
import vn.edu.studyai.floating.R
import vn.edu.studyai.floating.StudyAiApplication
import vn.edu.studyai.floating.ai.MultiProviderAiClient
import vn.edu.studyai.floating.capture.MediaProjectionHelper
import vn.edu.studyai.floating.data.local.HistoryRepository
import vn.edu.studyai.floating.data.local.HomeworkEntity
import vn.edu.studyai.floating.databinding.ActivityMainBinding
import vn.edu.studyai.floating.model.AiProviderType
import vn.edu.studyai.floating.model.AiSolveResult
import vn.edu.studyai.floating.model.QuestionType
import vn.edu.studyai.floating.model.SchoolSubject
import vn.edu.studyai.floating.model.StructuredSolution
import vn.edu.studyai.floating.ocr.OcrProcessor
import vn.edu.studyai.floating.overlay.FloatingSolverService
import vn.edu.studyai.floating.security.SecureConfigManager
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var configManager: SecureConfigManager
    private lateinit var aiClient: MultiProviderAiClient
    private lateinit var ocrProcessor: OcrProcessor
    private lateinit var historyRepository: HistoryRepository
    private lateinit var historyAdapter: HistoryAdapter

    private var currentPhotoUri: Uri? = null
    private var latestSolution: StructuredSolution? = null
    private var lastSimplifyMode: Boolean = false

    // Launcher mở cài đặt quyền SYSTEM_ALERT_WINDOW
    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startFloatingBubbleService()
        } else {
            Toast.makeText(
                this,
                "Bạn chưa cấp quyền Hiển thị trên ứng dụng khác nên nút nổi chưa thể kích hoạt.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // Launcher chụp ảnh bài tập qua Camera
    private val cameraTakePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = currentPhotoUri
        if (success && uri != null) {
            processImageUriWithOcr(uri, deleteTempFileAfterOcr = true)
        }
    }

    // Launcher chọn ảnh bài tập từ Thư viện
    private val galleryPickLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            processImageUriWithOcr(uri, deleteTempFileAfterOcr = false)
        }
    }

    // Launcher chụp màn hình theo cơ chế MediaProjection chính thức
    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            lifecycleScope.launch {
                binding.tvOcrConfidenceHint.text = "Đang chụp màn hình và nhận dạng chữ (OCR)..."
                val bitmap = MediaProjectionHelper.captureSingleFrame(
                    this@MainActivity,
                    result.resultCode,
                    result.data!!
                )
                if (bitmap != null) {
                    val ocrRes = ocrProcessor.recognizeFromBitmap(bitmap)
                    if (!bitmap.isRecycled) bitmap.recycle()
                    binding.etQuestionInput.setText(ocrRes.recognizedText)
                    binding.tvOcrConfidenceHint.text = ocrRes.userHint
                } else {
                    binding.tvOcrConfidenceHint.text =
                        "Không thể chụp màn hình (ứng dụng đích có thể chặn chụp bằng FLAG_SECURE)."
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        configManager = SecureConfigManager(this)
        aiClient = MultiProviderAiClient(this, configManager)
        ocrProcessor = OcrProcessor(this)
        historyRepository = HistoryRepository(this)

        setupSpinners()
        setupHistoryRecyclerView()
        setupClickListeners()
        updateConnectionBanner()
        refreshHistoryList()
        handleIncomingPrefillIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingPrefillIntent(intent)
    }

    private fun handleIncomingPrefillIntent(intent: Intent?) {
        val prefill = intent?.getStringExtra(FloatingSolverService.EXTRA_PREFILL_QUESTION)
        if (!prefill.isNullOrBlank()) {
            binding.etQuestionInput.setText(prefill)
            binding.tvOcrConfidenceHint.text =
                "Đã nhận nội dung từ Cửa sổ nổi / Chia sẻ. Bạn có thể chỉnh sửa trước khi bấm Giải bài."
        }
    }

    private fun setupSpinners() {
        val subjects = SchoolSubject.entries.map { it.displayName }
        binding.spinnerSubject.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            subjects
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        val questionTypes = QuestionType.entries.map { it.displayName }
        binding.spinnerQuestionType.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            questionTypes
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun setupHistoryRecyclerView() {
        historyAdapter = HistoryAdapter(
            onItemClick = { entity ->
                loadHistoryEntityIntoView(entity)
            },
            onDeleteClick = { entity ->
                lifecycleScope.launch {
                    historyRepository.deleteItem(entity.id)
                    refreshHistoryList(binding.etSearchHistory.text?.toString().orEmpty())
                }
            }
        )
        binding.rvHistoryList.layoutManager = LinearLayoutManager(this)
        binding.rvHistoryList.adapter = historyAdapter

        binding.etSearchHistory.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                refreshHistoryList(s?.toString().orEmpty())
            }
        })
    }

    private fun setupClickListeners() {
        // 1. Bật / Tắt Nút nổi AI trên mọi ứng dụng
        binding.btnToggleFloatingBubble.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                showOverlayPermissionExplanationDialog()
            } else {
                startFloatingBubbleService()
            }
        }

        // 2. Mở hộp thoại Cấu hình AI (Backend Proxy / Gemini / OpenAI)
        binding.btnOpenApiConfig.setOnClickListener {
            showAiConfigurationDialog()
        }

        // 3. Chuyển đổi chủ đề Sáng / Tối
        binding.btnToggleTheme.setOnClickListener {
            configManager.toggleNightMode()
        }

        // 4. Quản lý Dữ liệu cá nhân & Chính sách quyền riêng tư
        binding.btnOpenPrivacyManage.setOnClickListener {
            showPrivacyAndDataDialog()
        }

        // 5. Chụp ảnh bài tập bằng Camera
        binding.btnCameraCapture.setOnClickListener {
            launchCameraForHomework()
        }

        // 6. Chọn ảnh bài tập từ Thư viện
        binding.btnGalleryPick.setOnClickListener {
            galleryPickLauncher.launch("image/*")
        }

        // 7. Chụp màn hình theo cơ chế MediaProjection chính thức
        binding.btnScreenCapture.setOnClickListener {
            showScreenCaptureExplanationDialog()
        }

        // 8. Xóa ô nhập đề bài
        binding.btnClearInput.setOnClickListener {
            binding.etQuestionInput.setText("")
            binding.tvOcrConfidenceHint.text = "Đã xóa nội dung ô nhập đề bài."
        }

        // 9. Giải bài tập bằng AI
        binding.btnSolveMain.setOnClickListener {
            executeSolveHomework(simplifyMode = false)
        }

        // 10. Thử lại khi mất mạng hoặc timeout
        binding.btnRetryNetwork.setOnClickListener {
            executeSolveHomework(simplifyMode = lastSimplifyMode)
        }

        // 11. Giải thích lại bằng ngôn ngữ dễ hiểu hơn
        binding.btnSimplifyMain.setOnClickListener {
            executeSolveHomework(simplifyMode = true)
        }

        // 12. Sao chép lời giải
        binding.btnCopyMain.setOnClickListener {
            val sol = latestSolution
            if (sol == null) {
                Toast.makeText(this, "Chưa có lời giải để sao chép.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val subjectName = getSelectedSubject().displayName
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(
                ClipData.newPlainText("StudyAI Solution", sol.formatForClipboard(subjectName))
            )
            Toast.makeText(this, "Đã sao chép toàn bộ lời giải 6 phần!", Toast.LENGTH_SHORT).show()
        }

        // 13. Lưu lời giải vào lịch sử cục bộ
        binding.btnSaveMain.setOnClickListener {
            val sol = latestSolution
            if (sol == null) {
                Toast.makeText(this, "Chưa có lời giải để lưu.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                historyRepository.saveSolution(getSelectedSubject(), getSelectedQuestionType(), sol)
                refreshHistoryList(binding.etSearchHistory.text?.toString().orEmpty())
                Toast.makeText(this@MainActivity, "Đã lưu vào lịch sử câu hỏi!", Toast.LENGTH_SHORT).show()
            }
        }

        // 14. Xóa toàn bộ lịch sử
        binding.btnClearAllHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Xóa toàn bộ lịch sử câu hỏi?")
                .setMessage("Tất cả câu hỏi và lời giải đã lưu trên điện thoại sẽ bị xóa vĩnh viễn.")
                .setPositiveButton("Xóa hết") { _, _ ->
                    lifecycleScope.launch {
                        historyRepository.clearAll()
                        refreshHistoryList()
                        Toast.makeText(this@MainActivity, "Đã xóa sạch lịch sử câu hỏi.", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Hủy", null)
                .show()
        }
    }

    private fun showOverlayPermissionExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.overlay_permission_title))
            .setMessage(getString(R.string.overlay_permission_message))
            .setPositiveButton("Mở Cài đặt cấp quyền") { _, _ ->
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
            }
            .setNegativeButton("Để sau", null)
            .show()
    }

    private fun startFloatingBubbleService() {
        val currentInput = binding.etQuestionInput.text?.toString()?.trim().orEmpty()
        val serviceIntent = Intent(this, FloatingSolverService::class.java).apply {
            if (currentInput.isNotEmpty()) {
                action = FloatingSolverService.ACTION_SHOW_PANEL
                putExtra(FloatingSolverService.EXTRA_PREFILL_QUESTION, currentInput)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, serviceIntent)
        } else {
            startService(serviceIntent)
        }
        Toast.makeText(
            this,
            "Đã bật nút nổi StudyAI! Bạn có thể chuyển sang trình duyệt hoặc ứng dụng học tập khác.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun launchCameraForHomework() {
        try {
            val captureDir = File(cacheDir, "camera_captures").apply { mkdirs() }
            val tempFile = File.createTempFile("homework_capture_", ".jpg", captureDir)
            val uri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                tempFile
            )
            currentPhotoUri = uri
            cameraTakePictureLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Không thể khởi tạo Camera: ${e.message}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun processImageUriWithOcr(uri: Uri, deleteTempFileAfterOcr: Boolean) {
        lifecycleScope.launch {
            binding.tvOcrConfidenceHint.text =
                "Đang nhận dạng chữ tiếng Việt và công thức từ ảnh (OCR)..."
            val ocrResult = ocrProcessor.recognizeFromUri(uri)
            binding.etQuestionInput.setText(ocrResult.recognizedText)
            binding.tvOcrConfidenceHint.text = ocrResult.userHint

            if (deleteTempFileAfterOcr) {
                (application as? StudyAiApplication)?.cleanupTemporaryImages()
            }
        }
    }

    private fun showScreenCaptureExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.screen_capture_permission_title))
            .setMessage(getString(R.string.screen_capture_permission_message))
            .setPositiveButton("Đồng ý chụp màn hình") { _, _ ->
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
                if (mgr != null) {
                    screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
                }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun executeSolveHomework(simplifyMode: Boolean) {
        lastSimplifyMode = simplifyMode
        val questionText = binding.etQuestionInput.text?.toString().orEmpty()
        val subject = getSelectedSubject()
        val questionType = getSelectedQuestionType()

        binding.layoutLoadingStatus.visibility = View.VISIBLE
        binding.progressBarMain.visibility = View.VISIBLE
        binding.btnRetryNetwork.visibility = View.GONE
        binding.tvLoadingMessage.text = if (simplifyMode) {
            "Đang yêu cầu AI diễn giải lại dễ hiểu hơn..."
        } else {
            "Đang giải bài tập môn ${subject.displayName} (${questionType.displayName})..."
        }

        lifecycleScope.launch {
            val result = aiClient.solveHomework(
                questionText = questionText,
                subject = subject,
                questionType = questionType,
                simplifyMode = simplifyMode
            )
            when (result) {
                is AiSolveResult.Success -> {
                    binding.layoutLoadingStatus.visibility = View.GONE
                    latestSolution = result.solution
                    bindStructuredSolutionToUi(result.solution)
                }
                is AiSolveResult.Error -> {
                    binding.progressBarMain.visibility = View.GONE
                    binding.tvLoadingMessage.text = result.userMessage
                    binding.btnRetryNetwork.visibility =
                        if (result.isRetryable) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun bindStructuredSolutionToUi(solution: StructuredSolution) {
        binding.tvSection1Recognized.text = solution.recognizedProblem
        binding.tvSection2Knowledge.text = solution.requiredKnowledge
        binding.tvSection3Steps.text = solution.stepByStepSolution
        binding.tvSection4FinalAnswer.text = solution.finalAnswer
        binding.tvSection5Verification.text = solution.verification
        binding.tvSection6Simplified.text = solution.simplifiedExplanation
    }

    private fun loadHistoryEntityIntoView(entity: HomeworkEntity) {
        val solution = entity.toStructuredSolution()
        latestSolution = solution
        binding.etQuestionInput.setText(entity.recognizedProblem)
        bindStructuredSolutionToUi(solution)
        binding.rootMainScroll.smoothScrollTo(0, binding.cardSolutionContainer.top)
    }

    private fun refreshHistoryList(query: String = "") {
        lifecycleScope.launch {
            val list = historyRepository.getHistory(query)
            historyAdapter.submitList(list)
            binding.tvHistoryHeader.text = "LỊCH SỬ CÂU HỎI ĐÃ LƯU (${list.size})"
        }
    }

    private fun getSelectedSubject(): SchoolSubject {
        val pos = binding.spinnerSubject.selectedItemPosition
        return SchoolSubject.entries.getOrElse(pos) { SchoolSubject.MATH }
    }

    private fun getSelectedQuestionType(): QuestionType {
        val pos = binding.spinnerQuestionType.selectedItemPosition
        return QuestionType.entries.getOrElse(pos) { QuestionType.AUTO }
    }

    private fun updateConnectionBanner() {
        if (configManager.isConfiguredReady()) {
            val provider = configManager.getProviderType()
            val model = configManager.getModelName()
            binding.tvConnectionBanner.text =
                "✅ Đã cấu hình AI: ${provider.displayName} (Model: $model). Sẵn sàng giải bài tập!"
        } else {
            binding.tvConnectionBanner.text = getString(R.string.api_not_configured_warning)
        }
    }

    private fun showAiConfigurationDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_api_config, null)
        val spinnerProvider = dialogView.findViewById<Spinner>(R.id.spinnerAiProvider)
        val etEndpoint = dialogView.findViewById<EditText>(R.id.etEndpointUrl)
        val etModel = dialogView.findViewById<EditText>(R.id.etModelName)
        val etApiKey = dialogView.findViewById<EditText>(R.id.etApiKeySecret)

        val providers = AiProviderType.entries
        spinnerProvider.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            providers.map { it.displayName }
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        val currentProvider = configManager.getProviderType()
        spinnerProvider.setSelection(providers.indexOf(currentProvider).coerceAtLeast(0))
        etEndpoint.setText(configManager.getEndpointUrl())
        etModel.setText(configManager.getModelName())
        etApiKey.setText(configManager.getApiKey())

        AlertDialog.Builder(this)
            .setTitle("Cấu hình dịch vụ AI & Bảo mật khóa")
            .setView(dialogView)
            .setPositiveButton("Lưu cấu hình") { _, _ ->
                val selectedProvider = providers.getOrElse(spinnerProvider.selectedItemPosition) {
                    AiProviderType.BACKEND_PROXY
                }
                val endpoint = etEndpoint.text?.toString().orEmpty()
                    .ifBlank { selectedProvider.defaultEndpoint }
                val model = etModel.text?.toString().orEmpty()
                    .ifBlank { selectedProvider.defaultModel }
                val key = etApiKey.text?.toString().orEmpty()

                configManager.saveAiConfiguration(selectedProvider, endpoint, model, key)
                updateConnectionBanner()
                Toast.makeText(this, "Đã lưu cấu hình kết nối AI an toàn!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun showPrivacyAndDataDialog() {
        lifecycleScope.launch {
            val savedCount = historyRepository.getCount()
            val message = buildString {
                appendLine("1. CHÍNH SÁCH QUYỀN RIÊNG TƯ & BẢO MẬT:")
                appendLine("• Ứng dụng chỉ gửi văn bản câu hỏi tới dịch vụ AI khi bạn chủ động bấm nút 'Giải bài' hoặc 'Giải thích lại'.")
                appendLine("• Ảnh chụp bài tập được xử lý nhận dạng chữ (OCR) cục bộ trên điện thoại và tự động xóa khỏi bộ nhớ đệm ngay sau khi nhận dạng xong.")
                appendLine("• Khóa API (nếu dùng) được mã hóa AES-256-GCM trong Android Keystore, không bao giờ ghi ra Logcat.")
                appendLine()
                appendLine("2. GIỚI HẠN KỸ THUẬT CỦA ANDROID:")
                appendLine("• Nút nổi và chụp màn hình KHÔNG hoạt động trên các ứng dụng ngân hàng, màn hình mật khẩu hoặc ứng dụng bật cờ bảo mật FLAG_SECURE.")
                appendLine("• Ứng dụng không sử dụng quyền Root, không tự khởi động cùng máy và không theo dõi thao tác nền.")
                appendLine()
                appendLine("3. DỮ LIỆU ĐANG LƯU TRÊN MÁY:")
                appendLine("• Số câu hỏi trong lịch sử cục bộ: $savedCount mục.")
            }

            AlertDialog.Builder(this@MainActivity)
                .setTitle("Quyền riêng tư & Quản lý dữ liệu cá nhân")
                .setMessage(message)
                .setPositiveButton("Đóng", null)
                .setNeutralButton("Xóa sạch mọi dữ liệu & Khóa API") { _, _ ->
                    lifecycleScope.launch {
                        historyRepository.clearAll()
                        configManager.clearAllPersonalAndConfigData()
                        (application as? StudyAiApplication)?.cleanupTemporaryImages()
                        updateConnectionBanner()
                        refreshHistoryList()
                        Toast.makeText(
                            this@MainActivity,
                            "Đã xóa toàn bộ lịch sử, ảnh đệm và cấu hình API trên thiết bị.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
                .show()
        }
    }
}
