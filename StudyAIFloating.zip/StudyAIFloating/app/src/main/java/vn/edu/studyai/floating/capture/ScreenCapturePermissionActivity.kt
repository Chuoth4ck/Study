package vn.edu.studyai.floating.capture

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import vn.edu.studyai.floating.R
import vn.edu.studyai.floating.overlay.FloatingSolverService

/**
 * Activity trong suốt dùng để hiển thị giải thích minh bạch và xin quyền MediaProjection
 * khi người dùng bấm "Chụp bài" từ cửa sổ nổi.
 */
class ScreenCapturePermissionActivity : ComponentActivity() {

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, FloatingSolverService::class.java).apply {
                action = FloatingSolverService.ACTION_EXECUTE_SCREEN_CAPTURE
                putExtra(FloatingSolverService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(FloatingSolverService.EXTRA_RESULT_INTENT, result.data)
            }
            startService(serviceIntent)
        } else {
            val restoreIntent = Intent(this, FloatingSolverService::class.java).apply {
                action = FloatingSolverService.ACTION_SHOW_PANEL
            }
            startService(restoreIntent)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.screen_capture_permission_title))
            .setMessage(getString(R.string.screen_capture_permission_message))
            .setCancelable(true)
            .setPositiveButton("Đồng ý chụp 1 ảnh") { _, _ ->
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
                if (mgr != null) {
                    captureLauncher.launch(mgr.createScreenCaptureIntent())
                } else {
                    finish()
                }
            }
            .setNegativeButton("Hủy") { _, _ ->
                finish()
            }
            .setOnCancelListener {
                finish()
            }
            .show()
    }
}
