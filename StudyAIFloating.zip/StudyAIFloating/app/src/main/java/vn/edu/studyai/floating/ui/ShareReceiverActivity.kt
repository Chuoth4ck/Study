package vn.edu.studyai.floating.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import vn.edu.studyai.floating.ocr.OcrProcessor
import vn.edu.studyai.floating.overlay.FloatingSolverService

/**
 * Nhận văn bản hoặc hình ảnh bài tập từ chức năng Chia sẻ (Share Sheet) của Android.
 * Nếu nhận được ảnh, tự động chạy OCR tiếng Việt rồi chuyển sang cửa sổ giải bài để học sinh chỉnh sửa.
 */
class ShareReceiverActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent?.action == Intent.ACTION_SEND) {
            val mimeType = intent.type.orEmpty()
            when {
                mimeType.startsWith("text/") -> {
                    val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty().trim()
                    routeQuestionToSolver(sharedText)
                    finish()
                }
                mimeType.startsWith("image/") -> {
                    val imageUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(Intent.EXTRA_STREAM)
                    }
                    if (imageUri != null) {
                        lifecycleScope.launch {
                            Toast.makeText(
                                this@ShareReceiverActivity,
                                "Đang nhận dạng chữ từ ảnh được chia sẻ...",
                                Toast.LENGTH_SHORT
                            ).show()
                            val ocrResult = OcrProcessor(this@ShareReceiverActivity).recognizeFromUri(imageUri)
                            routeQuestionToSolver(ocrResult.recognizedText)
                            finish()
                        }
                    } else {
                        Toast.makeText(this, "Không đọc được hình ảnh chia sẻ.", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
                else -> {
                    Toast.makeText(
                        this,
                        "Định dạng chia sẻ chưa được hỗ trợ ($mimeType).",
                        Toast.LENGTH_SHORT
                    ).show()
                    finish()
                }
            }
        } else {
            finish()
        }
    }

    private fun routeQuestionToSolver(questionText: String) {
        if (Settings.canDrawOverlays(this)) {
            val serviceIntent = Intent(this, FloatingSolverService::class.java).apply {
                action = FloatingSolverService.ACTION_SHOW_PANEL
                putExtra(FloatingSolverService.EXTRA_PREFILL_QUESTION, questionText)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } else {
            val mainIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(FloatingSolverService.EXTRA_PREFILL_QUESTION, questionText)
            }
            startActivity(mainIntent)
        }
    }
}
