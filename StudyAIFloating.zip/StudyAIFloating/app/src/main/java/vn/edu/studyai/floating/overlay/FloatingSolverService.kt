package vn.edu.studyai.floating.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import vn.edu.studyai.floating.R
import vn.edu.studyai.floating.StudyAiApplication
import vn.edu.studyai.floating.ai.MultiProviderAiClient
import vn.edu.studyai.floating.capture.MediaProjectionHelper
import vn.edu.studyai.floating.capture.ScreenCapturePermissionActivity
import vn.edu.studyai.floating.data.local.HistoryRepository
import vn.edu.studyai.floating.model.AiSolveResult
import vn.edu.studyai.floating.model.QuestionType
import vn.edu.studyai.floating.model.SchoolSubject
import vn.edu.studyai.floating.model.StructuredSolution
import vn.edu.studyai.floating.ocr.OcrProcessor
import vn.edu.studyai.floating.security.SecureConfigManager
import vn.edu.studyai.floating.ui.MainActivity
import kotlin.math.abs

/**
 * Dịch vụ Nút nổi (Floating Bubble) & Cửa sổ giải bài tập nổi (Floating Solver Panel)
 * trên mọi ứng dụng cho phép lớp phủ (SYSTEM_ALERT_WINDOW).
 *
 * Đặc điểm tối ưu cho OPPO A18 (RAM 4GB):
 * - Chỉ khởi chạy khi người dùng chủ động bật và đã cấp quyền SYSTEM_ALERT_WINDOW.
 * - Quản lý động cờ FLAG_NOT_FOCUSABLE: Khi không nhập liệu, không chiếm bàn phím của ứng dụng nền;
 *   khi bấm vào ô nhập đề bài, tự động bật nhận bàn phím ảo mượt mà.
 * - Tự động hít nút nổi về sát mép màn hình (Edge Snapping) để tránh che khuất nội dung học tập.
 */
class FloatingSolverService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var windowManager: WindowManager
    private lateinit var configManager: SecureConfigManager
    private lateinit var aiClient: MultiProviderAiClient
    private lateinit var ocrProcessor: OcrProcessor
    private lateinit var historyRepository: HistoryRepository

    private var bubbleView: View? = null
    private var panelView: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams

    private var currentSolution: StructuredSolution? = null
    private var isPanelVisible = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        configManager = SecureConfigManager(this)
        aiClient = MultiProviderAiClient(this, configManager)
        ocrProcessor = OcrProcessor(this)
        historyRepository = HistoryRepository(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Kiểm tra nghiêm ngặt quyền SYSTEM_ALERT_WINDOW trước khi tạo cửa sổ nổi
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Chưa có quyền Hiển thị trên ứng dụng khác. Dịch vụ nút nổi sẽ dừng.",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundSafely(includeMediaProjection = intent?.action == ACTION_EXECUTE_SCREEN_CAPTURE)
        ensureViewsInitialized()

        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW_PANEL -> {
                val prefilledText = intent.getStringExtra(EXTRA_PREFILL_QUESTION)
                showSolverPanel(prefilledText)
            }
            ACTION_EXECUTE_SCREEN_CAPTURE -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_INTENT)
                }
                if (resultData != null) {
                    performSingleScreenCaptureAndOcr(resultCode, resultData)
                } else {
                    showSolverPanel(null)
                }
            }
            else -> {
                if (!isPanelVisible) {
                    showBubbleOnly()
                }
            }
        }

        // Không tự động khởi động lại ngầm nếu hệ thống thu hồi để tiết kiệm RAM trên OPPO A18
        return START_NOT_STICKY
    }

    private fun startForegroundSafely(includeMediaProjection: Boolean) {
        val notification = buildForegroundNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val fgsType = if (includeMediaProjection) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            }
            startForeground(NOTIFICATION_ID, notification, fgsType)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingSolverService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pendingStop = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, StudyAiApplication.FLOATING_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_ai_bubble)
            .setContentTitle("Nút nổi StudyAI đang bật")
            .setContentText("Chạm vào nút nổi AI trên màn hình để giải bài tập nhanh.")
            .setContentIntent(pendingOpen)
            .addAction(0, "Tắt nút nổi", pendingStop)
            .setOngoing(true)
            .build()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun ensureViewsInitialized() {
        if (bubbleView != null && panelView != null) return

        val themedContext = ContextThemeWrapper(this, R.style.Theme_StudyAIFloating)
        val inflater = LayoutInflater.from(themedContext)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // 1. Khởi tạo thông số cửa sổ cho Nút nổi tròn (Bubble)
        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 280
        }

        // 2. Khởi tạo thông số cửa sổ cho Bảng giải bài tập nổi (Solver Panel)
        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = 140
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        bubbleView = inflater.inflate(R.layout.layout_floating_bubble, null)
        panelView = inflater.inflate(R.layout.layout_floating_solver, null)

        setupBubbleInteractions(bubbleView!!)
        setupPanelInteractions(panelView!!)

        windowManager.addView(bubbleView, bubbleParams)
        panelView?.visibility = View.GONE
        windowManager.addView(panelView, panelParams)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupBubbleInteractions(view: View) {
        val circleBtn = view.findViewById<View>(R.id.btnBubbleCircle)
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        circleBtn.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isDragging = true
                    }
                    bubbleParams.x = initialX + dx
                    bubbleParams.y = (initialY + dy).coerceAtLeast(48)
                    runCatching { windowManager.updateViewLayout(bubbleView, bubbleParams) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        showSolverPanel(null)
                    } else {
                        snapBubbleToNearestScreenEdge()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun snapBubbleToNearestScreenEdge() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)
        val screenWidth = metrics.widthPixels
        val bubbleWidth = bubbleView?.width?.takeIf { it > 0 } ?: 150
        bubbleParams.x = if (bubbleParams.x + bubbleWidth / 2 < screenWidth / 2) {
            12
        } else {
            (screenWidth - bubbleWidth - 12).coerceAtLeast(12)
        }
        runCatching { windowManager.updateViewLayout(bubbleView, bubbleParams) }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupPanelInteractions(view: View) {
        val dragHeader = view.findViewById<View>(R.id.floatingDragHeader)
        val btnExpandApp = view.findViewById<Button>(R.id.btnFloatingExpandApp)
        val btnMinimize = view.findViewById<Button>(R.id.btnFloatingMinimize)
        val btnClose = view.findViewById<Button>(R.id.btnFloatingClose)
        val spinnerSubject = view.findViewById<Spinner>(R.id.spinnerFloatingSubject)
        val btnCapture = view.findViewById<Button>(R.id.btnFloatingCapture)
        val btnFocusInput = view.findViewById<Button>(R.id.btnFloatingFocusInput)
        val btnSolve = view.findViewById<Button>(R.id.btnFloatingSolve)
        val etQuestion = view.findViewById<EditText>(R.id.etFloatingQuestion)
        val layoutLoading = view.findViewById<LinearLayout>(R.id.layoutFloatingLoading)
        val tvStatus = view.findViewById<TextView>(R.id.tvFloatingStatus)
        val tvFinalAnswer = view.findViewById<TextView>(R.id.tvFloatingFinalAnswer)
        val tvFullSolution = view.findViewById<TextView>(R.id.tvFloatingFullSolution)
        val btnSimplify = view.findViewById<Button>(R.id.btnFloatingSimplify)
        val btnCopy = view.findViewById<Button>(R.id.btnFloatingCopy)
        val btnSave = view.findViewById<Button>(R.id.btnFloatingSave)

        // Gắn danh sách 10 môn học vào Spinner của cửa sổ nổi
        val subjectNames = SchoolSubject.entries.map { it.displayName }
        val adapter = ArrayAdapter(
            view.context,
            android.R.layout.simple_spinner_item,
            subjectNames
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerSubject.adapter = adapter

        // Kéo thả di chuyển cửa sổ giải bài
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        dragHeader.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = panelParams.x
                    startY = panelParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    setPanelFocusable(false, etQuestion)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = startX + (event.rawX - touchX).toInt()
                    panelParams.y = (startY + (event.rawY - touchY).toInt()).coerceAtLeast(32)
                    runCatching { windowManager.updateViewLayout(panelView, panelParams) }
                    true
                }
                else -> false
            }
        }

        // Tự động bật nhận bàn phím ảo khi người dùng chạm vào ô nhập câu hỏi hoặc nút "Nhập đề"
        etQuestion.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                setPanelFocusable(true, etQuestion)
            }
            false
        }

        btnFocusInput.setOnClickListener {
            setPanelFocusable(true, etQuestion)
        }

        // Thu nhỏ cửa sổ về nút nổi tròn
        btnMinimize.setOnClickListener {
            setPanelFocusable(false, etQuestion)
            showBubbleOnly()
        }

        // Đóng hoàn toàn dịch vụ nút nổi
        btnClose.setOnClickListener {
            setPanelFocusable(false, etQuestion)
            stopSelf()
        }

        // Chuyển sang giao diện ứng dụng đầy đủ kèm nội dung câu hỏi hiện tại
        btnExpandApp.setOnClickListener {
            setPanelFocusable(false, etQuestion)
            val currentText = etQuestion.text?.toString()?.trim().orEmpty()
            val openIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_PREFILL_QUESTION, currentText)
            }
            startActivity(openIntent)
            showBubbleOnly()
        }

        // Nút Chụp bài từ cửa sổ nổi (Gọi cơ chế MediaProjection chính thức)
        btnCapture.setOnClickListener {
            setPanelFocusable(false, etQuestion)
            val permIntent = Intent(this, ScreenCapturePermissionActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(permIntent)
        }

        // Nút Giải bài
        btnSolve.setOnClickListener {
            setPanelFocusable(false, etQuestion)
            val question = etQuestion.text?.toString().orEmpty()
            val selectedSubject = SchoolSubject.fromDisplayName(
                spinnerSubject.selectedItem?.toString() ?: SchoolSubject.MATH.displayName
            )
            triggerAiSolveInOverlay(
                question = question,
                subject = selectedSubject,
                simplifyMode = false,
                layoutLoading = layoutLoading,
                tvStatus = tvStatus,
                tvFinalAnswer = tvFinalAnswer,
                tvFullSolution = tvFullSolution
            )
        }

        // Nút Giải thích lại dễ hiểu hơn
        btnSimplify.setOnClickListener {
            setPanelFocusable(false, etQuestion)
            val question = etQuestion.text?.toString().orEmpty()
            val selectedSubject = SchoolSubject.fromDisplayName(
                spinnerSubject.selectedItem?.toString() ?: SchoolSubject.MATH.displayName
            )
            triggerAiSolveInOverlay(
                question = question,
                subject = selectedSubject,
                simplifyMode = true,
                layoutLoading = layoutLoading,
                tvStatus = tvStatus,
                tvFinalAnswer = tvFinalAnswer,
                tvFullSolution = tvFullSolution
            )
        }

        // Nút Sao chép lời giải
        btnCopy.setOnClickListener {
            val sol = currentSolution
            if (sol == null) {
                Toast.makeText(this, "Chưa có lời giải để sao chép.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val selectedSubject = spinnerSubject.selectedItem?.toString() ?: "Bài tập"
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(
                ClipData.newPlainText("StudyAI Solution", sol.formatForClipboard(selectedSubject))
            )
            Toast.makeText(this, "Đã sao chép lời giải vào bộ nhớ tạm!", Toast.LENGTH_SHORT).show()
        }

        // Nút Lưu lời giải vào lịch sử cục bộ
        btnSave.setOnClickListener {
            val sol = currentSolution
            if (sol == null) {
                Toast.makeText(this, "Chưa có lời giải để lưu.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val selectedSubject = SchoolSubject.fromDisplayName(
                spinnerSubject.selectedItem?.toString() ?: SchoolSubject.MATH.displayName
            )
            serviceScope.launch {
                historyRepository.saveSolution(selectedSubject, QuestionType.AUTO, sol)
                Toast.makeText(
                    this@FloatingSolverService,
                    "Đã lưu vào lịch sử câu hỏi!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun triggerAiSolveInOverlay(
        question: String,
        subject: SchoolSubject,
        simplifyMode: Boolean,
        layoutLoading: LinearLayout,
        tvStatus: TextView,
        tvFinalAnswer: TextView,
        tvFullSolution: TextView
    ) {
        layoutLoading.visibility = View.VISIBLE
        tvStatus.text = if (simplifyMode) {
            "Đang tạo lời giải thích dễ hiểu hơn..."
        } else {
            "Đang giải bài tập môn ${subject.displayName}..."
        }

        serviceScope.launch {
            val result = aiClient.solveHomework(
                questionText = question,
                subject = subject,
                questionType = QuestionType.AUTO,
                simplifyMode = simplifyMode
            )
            layoutLoading.visibility = View.GONE
            when (result) {
                is AiSolveResult.Success -> {
                    currentSolution = result.solution
                    tvFinalAnswer.text = "Đáp án: ${result.solution.finalAnswer}"
                    tvFullSolution.text = result.solution.formatForFloatingOverlay()
                }
                is AiSolveResult.Error -> {
                    tvFinalAnswer.text = "Không thể hoàn tất giải bài"
                    tvFullSolution.text = result.userMessage
                }
            }
        }
    }

    /**
     * Tạm ẩn cửa sổ nổi 250ms, chụp đúng 1 ảnh màn hình qua MediaProjection,
     * chạy OCR nhận diện chữ + công thức toán, rồi hiện lại cửa sổ nổi để học sinh chỉnh sửa trước khi gửi.
     */
    private fun performSingleScreenCaptureAndOcr(resultCode: Int, resultData: Intent) {
        serviceScope.launch {
            bubbleView?.visibility = View.GONE
            panelView?.visibility = View.GONE
            delay(250L)

            val bitmap = MediaProjectionHelper.captureSingleFrame(
                this@FloatingSolverService,
                resultCode,
                resultData
            )

            showSolverPanel(null)
            val pView = panelView ?: return@launch
            val etQuestion = pView.findViewById<EditText>(R.id.etFloatingQuestion)
            val tvFinalAnswer = pView.findViewById<TextView>(R.id.tvFloatingFinalAnswer)
            val tvFullSolution = pView.findViewById<TextView>(R.id.tvFloatingFullSolution)

            if (bitmap == null) {
                tvFinalAnswer.text = "Không thể chụp màn hình này"
                tvFullSolution.text =
                    "Ứng dụng đang mở trên màn hình có thể đã bật cờ bảo mật chống chụp màn hình (FLAG_SECURE) hoặc hệ điều hành từ chối quyền."
                return@launch
            }

            tvFinalAnswer.text = "Đang nhận dạng chữ tiếng Việt & công thức (OCR)..."
            val ocrResult = ocrProcessor.recognizeFromBitmap(bitmap)
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }

            etQuestion.setText(ocrResult.recognizedText)
            tvFinalAnswer.text = if (ocrResult.isLowConfidenceOrEmpty) {
                "⚠️ Ảnh mờ hoặc ít chữ"
            } else {
                "Đã nhận dạng đề bài từ màn hình"
            }
            tvFullSolution.text = ocrResult.userHint
            setPanelFocusable(true, etQuestion)
        }
    }

    private fun setPanelFocusable(focusable: Boolean, editText: EditText) {
        val pView = panelView ?: return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        if (focusable) {
            panelParams.flags =
                panelParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            runCatching { windowManager.updateViewLayout(pView, panelParams) }
            editText.requestFocus()
            imm?.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
        } else {
            imm?.hideSoftInputFromWindow(editText.windowToken, 0)
            panelParams.flags =
                panelParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            runCatching { windowManager.updateViewLayout(pView, panelParams) }
        }
    }

    private fun showBubbleOnly() {
        isPanelVisible = false
        panelView?.visibility = View.GONE
        bubbleView?.visibility = View.VISIBLE
    }

    private fun showSolverPanel(prefilledQuestion: String?) {
        isPanelVisible = true
        bubbleView?.visibility = View.GONE
        panelView?.visibility = View.VISIBLE
        if (!prefilledQuestion.isNullOrBlank()) {
            panelView?.findViewById<EditText>(R.id.etFloatingQuestion)?.setText(prefilledQuestion)
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        runCatching {
            bubbleView?.let { windowManager.removeView(it) }
            panelView?.let { windowManager.removeView(it) }
        }
        bubbleView = null
        panelView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIFICATION_ID = 2026
        const val ACTION_SHOW_PANEL = "vn.edu.studyai.floating.ACTION_SHOW_PANEL"
        const val ACTION_STOP_SERVICE = "vn.edu.studyai.floating.ACTION_STOP_SERVICE"
        const val ACTION_EXECUTE_SCREEN_CAPTURE = "vn.edu.studyai.floating.ACTION_EXECUTE_SCREEN_CAPTURE"
        const val EXTRA_PREFILL_QUESTION = "extra_prefill_question"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_INTENT = "extra_result_intent"
    }
}
