package vn.edu.studyai.floating.model

/**
 * Danh sách 10 môn học chuẩn chương trình GDPT 2018 (THCS & THPT, trọng tâm Lớp 10).
 */
enum class SchoolSubject(
    val displayName: String,
    val curriculumHint: String
) {
    MATH(
        "Toán",
        "Mệnh đề, tập hợp, bất phương trình bậc nhất hai ẩn, hàm số bậc hai, hệ thức lượng trong tam giác, vectơ, thống kê - xác suất, đại số và giải tích."
    ),
    LITERATURE(
        "Ngữ văn",
        "Đọc hiểu văn bản thần thoại, sử thi, thơ Đường luật, chèo/tuồng, văn bản nghị luận, thực hành tiếng Việt và viết bài văn nghị luận xã hội/văn học."
    ),
    ENGLISH(
        "Tiếng Anh",
        "Ngữ pháp (Thì động từ, Câu bị động, Câu điều kiện, Mệnh đề quan hệ), từ vựng theo chủ đề Global Success lớp 10, đọc hiểu và viết lại câu."
    ),
    PHYSICS(
        "Vật lí",
        "Động học (chuyển động thẳng biến đổi đều, rơi tự do), Động lực học (3 định luật Newton), Năng lượng - Công - Công suất, Động lượng, Chuyển động tròn."
    ),
    CHEMISTRY(
        "Hóa học",
        "Cấu tạo nguyên tử, Bảng tuần hoàn các nguyên tố hóa học, Liên kết hóa học, Phản ứng oxi hóa - khử (cân bằng thăng bằng electron), Năng lượng hóa học."
    ),
    BIOLOGY(
        "Sinh học",
        "Thành phần hóa học của tế bào, Cấu trúc tế bào nhân sơ/nhân thực, Chuyển hóa vật chất và năng lượng trong tế bào, Chu kỳ tế bào và phân bào (Nguyên phân, Giảm phân)."
    ),
    HISTORY(
        "Lịch sử",
        "Lịch sử thế giới thời nguyên thủy - cổ - trung đại, các cuộc cách mạng công nghiệp, văn minh Đông Nam Á và các nền văn minh cổ trên đất nước Việt Nam."
    ),
    GEOGRAPHY(
        "Địa lí",
        "Bản đồ, Trái Đất, Thạch quyển, Khí quyển, Thủy quyển, Sinh quyển, Địa lí dân cư, Nguồn lực phát triển kinh tế và cơ cấu nền kinh tế."
    ),
    INFORMATICS(
        "Tin học",
        "Máy tính và xã hội tri thức, biểu diễn dữ liệu, mạng máy tính và Internet, đạo đức pháp luật số, thuật toán và lập trình cơ bản với Python."
    ),
    ECON_LAW(
        "Giáo dục kinh tế và pháp luật",
        "Cơ chế thị trường, ngân sách nhà nước, thuế, sản xuất kinh doanh, tín dụng, lập kế hoạch tài chính cá nhân, hệ thống pháp luật và Hiến pháp Việt Nam."
    );

    companion object {
        fun fromDisplayName(name: String): SchoolSubject {
            return entries.firstOrNull { it.displayName.equals(name.trim(), ignoreCase = true) } ?: MATH
        }
    }
}

enum class QuestionType(val displayName: String, val promptInstruction: String) {
    AUTO(
        "Tự động nhận diện",
        "Tự động xác định đây là câu hỏi trắc nghiệm (A/B/C/D hoặc Đúng/Sai) hay tự luận để giải phù hợp."
    ),
    MULTIPLE_CHOICE(
        "Trắc nghiệm",
        "Đây là câu hỏi trắc nghiệm. Bắt buộc nêu rõ đáp án đúng (A, B, C hoặc D), giải thích vì sao phương án đó đúng và chỉ ra lỗi sai/bẫy trong từng phương án còn lại nếu đủ dữ kiện."
    ),
    ESSAY(
        "Tự luận",
        "Đây là bài tập tự luận. Hãy trình bày lời giải từng bước chặt chẽ như bài làm chuẩn trên lớp."
    ),
    DOCUMENT_QA(
        "Câu hỏi tài liệu",
        "Đây là đoạn trích hoặc câu hỏi trong tài liệu học tập. Hãy tóm tắt ý chính và trả lời trọng tâm câu hỏi."
    )
}

enum class AiProviderType(val displayName: String, val defaultEndpoint: String, val defaultModel: String) {
    BACKEND_PROXY(
        "Backend Trung Gian (Khuyên dùng - Bảo vệ khóa API)",
        "https://your-studyai-proxy.example.com/api/v1/solve",
        "gemini-2.5-flash"
    ),
    GOOGLE_GEMINI(
        "Google Gemini API Chính thức",
        "https://generativelanguage.googleapis.com/v1beta/models",
        "gemini-2.5-flash"
    ),
    OPENAI_COMPATIBLE(
        "OpenAI / Tương thích OpenAI API",
        "https://api.openai.com/v1/chat/completions",
        "gpt-4o-mini"
    )
}

/**
 * Cấu trúc 6 phần bắt buộc cho lời giải của StudyAI Floating.
 */
data class StructuredSolution(
    val recognizedProblem: String,
    val requiredKnowledge: String,
    val stepByStepSolution: String,
    val finalAnswer: String,
    val verification: String,
    val simplifiedExplanation: String,
    val needsClarification: Boolean = false,
    val clarificationReason: String = ""
) {
    fun formatForFloatingOverlay(): String {
        if (needsClarification) {
            return buildString {
                appendLine("⚠️ CẦN BỔ SUNG DỮ KIỆN HOẶC CHỤP LẠI ẢNH:")
                appendLine(clarificationReason.ifBlank { finalAnswer })
                appendLine()
                appendLine("1. Đề bài nhận diện được:")
                appendLine(recognizedProblem)
            }.trim()
        }
        return buildString {
            appendLine("1. Đề bài nhận diện:")
            appendLine(recognizedProblem)
            appendLine()
            appendLine("2. Kiến thức cần dùng:")
            appendLine(requiredKnowledge)
            appendLine()
            appendLine("3. Các bước giải chi tiết:")
            appendLine(stepByStepSolution)
            appendLine()
            appendLine("5. Kiểm tra lại:")
            appendLine(verification)
            appendLine()
            appendLine("6. Giải thích dễ hiểu hơn:")
            appendLine(simplifiedExplanation)
        }.trim()
    }

    fun formatForClipboard(subjectName: String): String {
        return buildString {
            appendLine("=== LỜI GIẢI STUDYAI ($subjectName) ===")
            appendLine("1. Đề bài nhận diện: $recognizedProblem")
            appendLine("2. Kiến thức cần dùng: $requiredKnowledge")
            appendLine("3. Các bước giải:
$stepByStepSolution")
            appendLine("4. ĐÁP ÁN CUỐI CÙNG: $finalAnswer")
            appendLine("5. Kiểm tra lại: $verification")
            appendLine("6. Giải thích dễ hiểu hơn: $simplifiedExplanation")
        }.trim()
    }
}

sealed class AiSolveResult {
    data class Success(val solution: StructuredSolution) : AiSolveResult()
    data class Error(val userMessage: String, val isRetryable: Boolean) : AiSolveResult()
}
