package vn.edu.studyai.floating.ocr

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

data class OcrResult(
    val recognizedText: String,
    val isLowConfidenceOrEmpty: Boolean,
    val userHint: String
)

/**
 * Xử lý nhận dạng chữ tiếng Việt và chuẩn hóa công thức toán học cơ bản từ ảnh bài tập.
 * Giải phóng Bitmap ngay lập tức sau khi nhận diện xong để bảo vệ RAM trên OPPO A18.
 */
class OcrProcessor(private val context: Context) {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognizeFromUri(imageUri: Uri): OcrResult = withContext(Dispatchers.Default) {
        val bitmap = BitmapMemoryOptimizer.decodeSampledBitmapFromUri(context, imageUri)
            ?: return@withContext OcrResult(
                recognizedText = "",
                isLowConfidenceOrEmpty = true,
                userHint = "Không thể đọc được file ảnh. Vui lòng chụp lại hoặc chọn ảnh rõ nét hơn."
            )
        try {
            recognizeFromBitmap(bitmap)
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    suspend fun recognizeFromBitmap(bitmap: Bitmap): OcrResult = withContext(Dispatchers.Default) {
        try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val visionText = recognizer.process(inputImage).await()
            val rawText = visionText.text.trim()
            val cleanedText = postProcessVietnameseAndMathText(rawText)

            if (cleanedText.length < 5) {
                OcrResult(
                    recognizedText = cleanedText,
                    isLowConfidenceOrEmpty = true,
                    userHint = "Ảnh mờ hoặc có quá ít chữ nhận diện được. Vui lòng kiểm tra, nhập bổ sung hoặc chụp lại ảnh rõ nét hơn!"
                )
            } else {
                OcrResult(
                    recognizedText = cleanedText,
                    isLowConfidenceOrEmpty = false,
                    userHint = "Đã nhận dạng văn bản từ ảnh. Bạn hãy kiểm tra và chỉnh sửa lại công thức (nếu cần) trước khi bấm Giải bài."
                )
            }
        } catch (e: Exception) {
            OcrResult(
                recognizedText = "",
                isLowConfidenceOrEmpty = true,
                userHint = "Lỗi nhận dạng chữ OCR: ${e.message ?: "Không xác định"}. Bạn có thể nhập đề bài thủ công."
            )
        }
    }

    companion object {
        /**
         * Chuẩn hóa văn bản tiếng Việt và các ký hiệu toán học/hóa học thường bị OCR nhận diện lệch.
         */
        fun postProcessVietnameseAndMathText(raw: String): String {
            if (raw.isBlank()) return ""
            return raw
                .replace("
", "
")
                .replace(Regex("[ \t]{2,}"), " ")
                // Chuẩn hóa các phương án trắc nghiệm đứng đầu dòng
                .replace(Regex("(?m)^([ABCD])\s*[.,:;]\s*"), "$1. ")
                // Chuẩn hóa ký hiệu mũi tên phản ứng / suy ra
                .replace("->", "→")
                .replace("=>", "⇒")
                .replace(">=", "≥")
                .replace("<=", "≤")
                .replace("!=", "≠")
                .replace("+-", "±")
                .trim()
        }
    }
}
