package vn.edu.studyai.floating.data.local

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import vn.edu.studyai.floating.model.QuestionType
import vn.edu.studyai.floating.model.SchoolSubject
import vn.edu.studyai.floating.model.StructuredSolution

class HistoryRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).homeworkDao()

    suspend fun getHistory(searchQuery: String = ""): List<HomeworkEntity> = withContext(Dispatchers.IO) {
        val trimmed = searchQuery.trim()
        if (trimmed.isEmpty()) {
            dao.getAllRecent()
        } else {
            dao.searchHistory(trimmed)
        }
    }

    suspend fun saveSolution(
        subject: SchoolSubject,
        questionType: QuestionType,
        solution: StructuredSolution
    ): Long = withContext(Dispatchers.IO) {
        val entity = HomeworkEntity(
            subjectName = subject.displayName,
            questionType = questionType.displayName,
            recognizedProblem = solution.recognizedProblem,
            requiredKnowledge = solution.requiredKnowledge,
            stepByStepSolution = solution.stepByStepSolution,
            finalAnswer = solution.finalAnswer,
            verification = solution.verification,
            simplifiedExplanation = solution.simplifiedExplanation
        )
        dao.insertHomework(entity)
    }

    suspend fun deleteItem(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteById(id)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        dao.clearAllHistory()
    }

    suspend fun getCount(): Int = withContext(Dispatchers.IO) {
        dao.countHistoryItems()
    }
}
