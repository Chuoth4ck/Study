package vn.edu.studyai.floating.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import vn.edu.studyai.floating.model.AiProviderType
import vn.edu.studyai.floating.model.AiSolveResult
import vn.edu.studyai.floating.model.QuestionType
import vn.edu.studyai.floating.model.SchoolSubject
import vn.edu.studyai.floating.security.SecureConfigManager
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

interface AiSolverService {
    suspend fun solveHomework(
        questionText: String,
        subject: SchoolSubject,
        questionType: QuestionType,
        simplifyMode: Boolean = false
    ): AiSolveResult
}

/**
 * Triển khai dịch vụ gọi AI qua HTTPS với OkHttp3 + Coroutines.
 * Hỗ trợ đổi nhà cung cấp AI linh hoạt (Backend Proxy, Google Gemini, OpenAI-compatible).
 * Tối ưu cho OPPO A18: kiểm soát timeout chặt chẽ (20s), tự động thử lại tối đa 1 lần khi mạng chập chờn,
 * không rò rỉ khóa API ra thông báo lỗi.
 */
class MultiProviderAiClient(
    private val context: Context,
    private val configManager: SecureConfigManager
) : AiSolverService {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    override suspend fun solveHomework(
        questionText: String,
        subject: SchoolSubject,
        questionType: QuestionType,
        simplifyMode: Boolean
    ): AiSolveResult = withContext(Dispatchers.IO) {
        // 1. Kiểm tra tính hợp lệ của đề bài đầu vào (chống gửi chuỗi rỗng/quá ngắn)
        val validationError = AiPromptBuilder.validateInputBeforeSending(questionText)
        if (validationError != null) {
            return@withContext AiSolveResult.Error(validationError, isRetryable = false)
        }

        // 2. Kiểm tra cấu hình AI trước khi gọi mạng
        if (!configManager.isConfiguredReady()) {
            return@withContext AiSolveResult.Error(
                "Chưa cấu hình kết nối AI! Vui lòng mở mục 'Cấu hình AI' để nhập địa chỉ Backend Proxy hoặc API Key cá nhân hợp lệ.",
                isRetryable = false
            )
        }

        // 3. Kiểm tra trạng thái mạng
        if (!isNetworkAvailable()) {
            return@withContext AiSolveResult.Error(
                "Không có kết nối Internet. Vui lòng kiểm tra Wi-Fi hoặc dữ liệu di động rồi bấm 'Thử lại'.",
                isRetryable = true
            )
        }

        val prompt = AiPromptBuilder.buildSolvePrompt(questionText, subject, questionType, simplifyMode)
        val provider = configManager.getProviderType()
        val endpoint = configManager.getEndpointUrl()
        val model = configManager.getModelName()
        val apiKey = configManager.getApiKey()

        var lastException: Exception? = null
        // Thử tối đa 2 lần (1 lần chính + 1 lần retry nhẹ nếu timeout tạm thời)
        for (attempt in 1..2) {
            try {
                val rawResponseText = executeProviderCall(provider, endpoint, model, apiKey, prompt)
                val structured = AiResponseParser.parseAiTextToStructuredSolution(rawResponseText, questionText)
                return@withContext AiSolveResult.Success(structured)
            } catch (e: SocketTimeoutException) {
                lastException = e
                if (attempt == 1) delay(800L)
            } catch (e: UnknownHostException) {
                return@withContext AiSolveResult.Error(
                    "Không thể phân giải máy chủ AI. Vui lòng kiểm tra kết nối mạng hoặc địa chỉ Endpoint.",
                    isRetryable = true
                )
            } catch (e: AiHttpException) {
                return@withContext handleHttpError(e.statusCode, e.message, apiKey)
            } catch (e: Exception) {
                lastException = e
                break
            }
        }

        val safeError = SecureConfigManager.sanitizeSensitiveErrorMessage(lastException?.message, apiKey)
        val message = if (lastException is SocketTimeoutException) {
            "Máy chủ AI phản hồi quá thời gian chờ (Timeout). Vui lòng bấm 'Thử lại'."
        } else {
            "Lỗi kết nối dịch vụ AI: $safeError"
        }
        return@withContext AiSolveResult.Error(message, isRetryable = true)
    }

    private fun executeProviderCall(
        provider: AiProviderType,
        endpoint: String,
        model: String,
        apiKey: String,
        prompt: String
    ): String {
        val jsonMediaType = "application/json; charset=utf-8".toMediaType()

        return when (provider) {
            AiProviderType.BACKEND_PROXY -> {
                val bodyJson = JSONObject().apply {
                    put("prompt", prompt)
                    put("model", model)
                }
                val reqBuilder = Request.Builder()
                    .url(endpoint)
                    .post(bodyJson.toString().toRequestBody(jsonMediaType))
                if (apiKey.isNotEmpty()) {
                    reqBuilder.addHeader("Authorization", "Bearer $apiKey")
                }
                performRequestAndExtractContent(reqBuilder.build(), AiProviderType.BACKEND_PROXY)
            }

            AiProviderType.GOOGLE_GEMINI -> {
                val cleanBase = endpoint.trimEnd('/')
                val fullUrl = "$cleanBase/$model:generateContent?key=$apiKey"
                val partObj = JSONObject().put("text", prompt)
                val contentObj = JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(partObj))
                val genConfig = JSONObject()
                    .put("temperature", 0.2)
                    .put("responseMimeType", "application/json")
                val payload = JSONObject()
                    .put("contents", JSONArray().put(contentObj))
                    .put("generationConfig", genConfig)

                val request = Request.Builder()
                    .url(fullUrl)
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()
                performRequestAndExtractContent(request, AiProviderType.GOOGLE_GEMINI)
            }

            AiProviderType.OPENAI_COMPATIBLE -> {
                val msgArray = JSONArray().apply {
                    put(
                        JSONObject()
                            .put("role", "system")
                            .put("content", "Bạn là trợ lý giải bài tập StudyAI cho học sinh Việt Nam. Luôn trả về JSON hợp lệ.")
                    )
                    put(
                        JSONObject()
                            .put("role", "user")
                            .put("content", prompt)
                    )
                }
                val payload = JSONObject()
                    .put("model", model)
                    .put("messages", msgArray)
                    .put("temperature", 0.2)

                val request = Request.Builder()
                    .url(endpoint)
                    .addHeader("Authorization", "Bearer $apiKey")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()
                performRequestAndExtractContent(request, AiProviderType.OPENAI_COMPATIBLE)
            }
        }
    }

    private fun performRequestAndExtractContent(request: Request, providerType: AiProviderType): String {
        httpClient.newCall(request).execute().use { response ->
            val rawBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                throw AiHttpException(response.code, "HTTP ${response.code}")
            }
            if (rawBody.isBlank()) {
                throw IOException("Máy chủ AI trả về dữ liệu rỗng.")
            }
            val root = JSONObject(rawBody)
            return when (providerType) {
                AiProviderType.GOOGLE_GEMINI, AiProviderType.BACKEND_PROXY -> {
                    if (root.has("candidates")) {
                        root.getJSONArray("candidates")
                            .getJSONObject(0)
                            .getJSONObject("content")
                            .getJSONArray("parts")
                            .getJSONObject(0)
                            .getString("text")
                    } else if (root.has("recognizedProblem")) {
                        rawBody
                    } else {
                        root.optString("text", rawBody)
                    }
                }
                AiProviderType.OPENAI_COMPATIBLE -> {
                    root.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                }
            }
        }
    }

    private fun handleHttpError(statusCode: Int, rawMsg: String?, apiKey: String): AiSolveResult.Error {
        return when (statusCode) {
            400 -> AiSolveResult.Error(
                "Yêu cầu không hợp lệ (HTTP 400). Vui lòng kiểm tra tên mô hình AI hoặc nội dung câu hỏi.",
                isRetryable = false
            )
            401, 403 -> AiSolveResult.Error(
                "API Key hoặc Token không hợp lệ / đã hết hạn (HTTP $statusCode). Vui lòng mở 'Cấu hình AI' để kiểm tra lại khóa.",
                isRetryable = false
            )
            429 -> AiSolveResult.Error(
                "Đã vượt giới hạn số lượt gọi API trong phút (HTTP 429). Vui lòng đợi vài giây rồi bấm 'Thử lại'.",
                isRetryable = true
            )
            in 500..599 -> AiSolveResult.Error(
                "Máy chủ AI đang bận hoặc bảo trì (HTTP $statusCode). Vui lòng bấm 'Thử lại' sau ít giây.",
                isRetryable = true
            )
            else -> AiSolveResult.Error(
                "Lỗi HTTP $statusCode: ${SecureConfigManager.sanitizeSensitiveErrorMessage(rawMsg, apiKey)}",
                isRetryable = true
            )
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private class AiHttpException(val statusCode: Int, message: String) : IOException(message)
}
