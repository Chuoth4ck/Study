package vn.edu.studyai.floating.ai

import vn.edu.studyai.floating.model.QuestionType
import vn.edu.studyai.floating.model.SchoolSubject

/**
 * Xây dựng Prompt sư phạm chuẩn chương trình phổ thông Việt Nam (THCS & THPT - Lớp 10).
 * Bắt buộc trả về 6 phần cấu trúc JSON và tuân thủ nguyên tắc KHÔNG BỊA ĐÁP ÁN khi thiếu dữ kiện.
 */
object AiPromptBuilder {

    fun validateInputBeforeSending(rawQuestion: String): String? {
        val cleaned = rawQuestion.trim()
        if (cleaned.isEmpty()) {
            return "Đề bài đang trống. Vui lòng nhập câu hỏi hoặc chụp lại ảnh bài tập rõ nét hơn."
        }
        if (cleaned.length < 4) {
            return "Nội dung đề bài quá ngắn hoặc chưa đủ dữ kiện ("$cleaned"). Vui lòng nhập đầy đủ câu hỏi hoặc chụp lại ảnh."
        }
        return null
    }

    fun buildSolvePrompt(
        questionText: String,
        subject: SchoolSubject,
        questionType: QuestionType,
        simplifyMode: Boolean = false
    ): String {
        val extraSimplifyInstruction = if (simplifyMode) {
            """
            YÊU CẦU ĐẶC BIỆT (CHẾ ĐỘ GIẢI THÍCH LẠI DỄ HIỂU HƠN):
            Học sinh đang yêu cầu giải thích lại bài này bằng ngôn ngữ cực kỳ đơn giản, gần gũi,
            chia nhỏ từng ý và có ví dụ minh họa trực quan để học sinh trung bình cũng hiểu ngay.
            """.trimIndent()
        } else {
            ""
        }

        return """
Bạn là trợ lý gia sư AI chuyên nghiệp dành cho học sinh THCS và THPT tại Việt Nam (đặc biệt là chương trình GDPT 2018 lớp 10).
Môn học hiện tại: ${subject.displayName} (${subject.curriculumHint})
Dạng bài: ${questionType.displayName} - ${questionType.promptInstruction}
$extraSimplifyInstruction

NGUYÊN TẮC BẮT BUỘC:
1. KHÔNG BỊA ĐÁP ÁN: Nếu đề bài dưới đây bị mất chữ nghiêm trọng do OCR, thiếu số liệu, thiếu vế phương trình hoặc thiếu các phương án trắc nghiệm khiến không thể giải chính xác, hãy đặt `"needsClarification": true` và nêu rõ phần bị thiếu trong `"clarificationReason"`, yêu cầu học sinh chụp lại hoặc bổ sung thông tin.
2. ĐỐI VỚI CÂU TRẮC NGHIỆM: Nếu đề bài có các phương án A, B, C, D (hoặc mệnh đề Đúng/Sai), trong phần `"stepByStepSolution"` phải giải thích rõ vì sao đáp án chọn là ĐÚNG và chỉ ra lỗi sai hoặc lý do loại trừ các phương án còn lại khi có đủ dữ kiện.
3. KÝ HIỆU TOÁN HỌC & KHOA HỌC: Trình bày công thức rõ ràng, dễ đọc trên điện thoại Android (ví dụ: x^2, √(x+1), Δ = b^2 - 4ac, →, ≤, ≥).

Hãy trả lời DUY NHẤT bằng một đối tượng JSON hợp lệ theo đúng cấu trúc 6 mục sau (không kèm lời chào ngoài JSON):
{
  "recognizedProblem": "Ghi lại chính xác nội dung đề bài đã nhận diện và chuẩn hóa",
  "requiredKnowledge": "Liệt kê định lý, công thức hoặc kiến thức sách giáo khoa cần dùng",
  "stepByStepSolution": "Trình bày từng bước giải chi tiết, dễ hiểu; phân tích cả các phương án sai nếu là trắc nghiệm",
  "finalAnswer": "Kết luận đáp án cuối cùng ngắn gọn, rõ ràng",
  "verification": "Kiểm tra lại kết quả (thay số ngược lại, kiểm tra điều kiện xác định, đơn vị đo hoặc tính hợp lý)",
  "simplifiedExplanation": "Tóm tắt mẹo nhớ nhanh hoặc cách hiểu đơn giản nhất cho học sinh",
  "needsClarification": false,
  "clarificationReason": ""
}

ĐỀ BÀI CỦA HỌC SINH:
""" + "\n" + questionText.trim()
    }
}
