package vn.edu.studyai.floating.ai

import org.json.JSONObject
import vn.edu.studyai.floating.model.StructuredSolution

/**
 * Bộ phân tích phản hồi AI thành 6 mục chuẩn của StudyAI Floating.
 * Hỗ trợ cả JSON chuẩn và Fallback khi mô hình trả về Markdown bọc JSON hoặc văn bản có tiêu đề.
 */
object AiResponseParser {

    fun parseAiTextToStructuredSolution(
        rawAiOutput: String,
        originalQuestion: String
    ): StructuredSolution {
        val cleanedJsonCandidate = extractJsonObjectString(rawAiOutput)
        if (cleanedJsonCandidate != null) {
            try {
                val obj = JSONObject(cleanedJsonCandidate)
                val needsClarification = obj.optBoolean("needsClarification", false)
                val clarificationReason = obj.optString("clarificationReason", "").trim()
                val recognized = obj.optString("recognizedProblem", originalQuestion).trim()
                    .ifEmpty { originalQuestion }
                val knowledge = obj.optString("requiredKnowledge", "Áp dụng kiến thức cơ bản trong sách giáo khoa.").trim()
                val steps = obj.optString("stepByStepSolution", "").trim()
                val finalAns = obj.optString("finalAnswer", "").trim()
                val verify = obj.optString("verification", "Đã đối chiếu điều kiện và phép tính.").trim()
                val simple = obj.optString("simplifiedExplanation", "").trim()

                if (needsClarification) {
                    val reason = clarificationReason.ifEmpty {
                        "Đề bài bị mờ hoặc thiếu dữ kiện quan trọng. Vui lòng chụp lại ảnh rõ hơn hoặc nhập bổ sung thông tin."
                    }
                    return StructuredSolution(
                        recognizedProblem = recognized,
                        requiredKnowledge = "Chưa thể xác định đầy đủ do thiếu dữ kiện đề bài.",
                        stepByStepSolution = reason,
                        finalAnswer = "Cần bổ sung thêm dữ kiện hoặc chụp lại ảnh rõ nét hơn.",
                        verification = "Tạm dừng giải để tránh suy đoán sai đáp án.",
                        simplifiedExplanation = reason,
                        needsClarification = true,
                        clarificationReason = reason
                    )
                }

                if (steps.isNotEmpty() || finalAns.isNotEmpty()) {
                    return StructuredSolution(
                        recognizedProblem = formatMathSymbolsForDisplay(recognized),
                        requiredKnowledge = formatMathSymbolsForDisplay(knowledge),
                        stepByStepSolution = formatMathSymbolsForDisplay(steps.ifEmpty { "Xem đáp án và giải thích bên dưới." }),
                        finalAnswer = formatMathSymbolsForDisplay(finalAns.ifEmpty { "Xem kết quả ở bước cuối." }),
                        verification = formatMathSymbolsForDisplay(verify),
                        simplifiedExplanation = formatMathSymbolsForDisplay(
                            simple.ifEmpty { "Nắm vững công thức ở mục 2 và làm lần lượt từng bước ở mục 3." }
                        ),
                        needsClarification = false,
                        clarificationReason = ""
                    )
                }
            } catch (_: Exception) {
                // Chuyển sang cơ chế phân tích văn bản dự phòng bên dưới
            }
        }

        // Fallback: Nếu AI trả về văn bản thuần không phải JSON
        val normalized = formatMathSymbolsForDisplay(rawAiOutput.trim())
        return StructuredSolution(
            recognizedProblem = originalQuestion.trim(),
            requiredKnowledge = "Kiến thức trọng tâm theo chương trình phổ thông.",
            stepByStepSolution = normalized,
            finalAnswer = extractFinalAnswerLine(normalized),
            verification = "Hãy kiểm tra lại điều kiện xác định và đơn vị của bài toán.",
            simplifiedExplanation = "Đọc kỹ từng bước biến đổi ở mục 3 để nắm quy tắc giải."
        )
    }

    private fun extractJsonObjectString(raw: String): String? {
        val trimmed = raw.trim()
        val firstBrace = trimmed.indexOf('{')
        val lastBrace = trimmed.lastIndexOf('}')
        if (firstBrace >= 0 && lastBrace > firstBrace) {
            return trimmed.substring(firstBrace, lastBrace + 1)
        }
        return null
    }

    private fun extractFinalAnswerLine(text: String): String {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val match = lines.firstOrNull { line ->
            val lower = line.lowercase()
            lower.startsWith("đáp án") || lower.startsWith("kết luận") || lower.startsWith("vậy ")
        }
        return match ?: lines.lastOrNull() ?: "Xem chi tiết trong các bước giải."
    }

    /**
     * Chuyển đổi một số ký hiệu LaTeX phổ biến sang ký hiệu Unicode Toán học dễ đọc trên màn hình nhỏ.
     */
    fun formatMathSymbolsForDisplay(input: String): String {
        return input
            .replace("\\sqrt", "√")
            .replace("\sqrt", "√")
            .replace("\\pm", "±")
            .replace("\pm", "±")
            .replace("\\leq", "≤")
            .replace("\leq", "≤")
            .replace("\\geq", "≥")
            .replace("\geq", "≥")
            .replace("\\neq", "≠")
            .replace("\neq", "≠")
            .replace("\\approx", "≈")
            .replace("\approx", "≈")
            .replace("\\pi", "π")
            .replace("\pi", "π")
            .replace("\\Delta", "Δ")
            .replace("\Delta", "Δ")
            .replace("\\rightarrow", "→")
            .replace("\rightarrow", "→")
            .replace("\\Rightarrow", "⇒")
            .replace("\Rightarrow", "⇒")
            .replace("\\times", "×")
            .replace("\times", "×")
            .replace("\\div", "÷")
            .replace("\div", "÷")
    }
}
