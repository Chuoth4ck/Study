package vn.edu.studyai.floating.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Hỗ trợ chụp đúng 1 khung hình màn hình theo cơ chế MediaProjection chính thức của Android.
 * Tự động giải phóng VirtualDisplay và dừng MediaProjection ngay lập tức sau khi lấy xong 1 ảnh,
 * tuyệt đối không quay màn hình ngầm liên tục.
 */
object MediaProjectionHelper {

    suspend fun captureSingleFrame(
        context: Context,
        resultCode: Int,
        permissionData: Intent
    ): Bitmap? = suspendCancellableCoroutine { continuation ->
        val projectionManager =
            context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        val windowManager =
            context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager

        if (projectionManager == null || windowManager == null) {
            if (continuation.isActive) continuation.resume(null)
            return@suspendCancellableCoroutine
        }

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        // Thu nhỏ kích thước chụp trên thiết bị RAM 4GB (giới hạn chiều ngang tối đa 720px)
        val scale = if (metrics.widthPixels > 720) 720f / metrics.widthPixels else 1f
        val width = (metrics.widthPixels * scale).toInt().coerceAtLeast(360)
        val height = (metrics.heightPixels * scale).toInt().coerceAtLeast(640)
        val density = metrics.densityDpi

        val mediaProjection: MediaProjection? = try {
            projectionManager.getMediaProjection(resultCode, permissionData)
        } catch (_: Exception) {
            null
        }

        if (mediaProjection == null) {
            if (continuation.isActive) continuation.resume(null)
            return@suspendCancellableCoroutine
        }

        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        var virtualDisplay: VirtualDisplay? = null
        var hasCaptured = false
        val mainHandler = Handler(Looper.getMainLooper())

        fun cleanup() {
            runCatching { virtualDisplay?.release() }
            runCatching { imageReader.close() }
            runCatching { mediaProjection.stop() }
        }

        imageReader.setOnImageAvailableListener({ reader ->
            if (hasCaptured) return@setOnImageAvailableListener
            val image = try {
                reader.acquireLatestImage()
            } catch (_: Exception) {
                null
            } ?: return@setOnImageAvailableListener

            hasCaptured = true
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width

                val tempBitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                tempBitmap.copyPixelsFromBuffer(buffer)
                val croppedBitmap = Bitmap.createBitmap(tempBitmap, 0, 0, width, height)
                if (croppedBitmap != tempBitmap) {
                    tempBitmap.recycle()
                }
                image.close()
                cleanup()
                if (continuation.isActive) {
                    continuation.resume(croppedBitmap)
                }
            } catch (_: Exception) {
                runCatching { image.close() }
                cleanup()
                if (continuation.isActive) {
                    continuation.resume(null)
                }
            }
        }, mainHandler)

        try {
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "StudyAISingleCapture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                mainHandler
            )
        } catch (_: Exception) {
            cleanup()
            if (continuation.isActive) continuation.resume(null)
        }

        continuation.invokeOnCancellation {
            cleanup()
        }
    }
}
