package vn.edu.studyai.floating.security

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import vn.edu.studyai.floating.model.AiProviderType

/**
 * Quản lý cấu hình AI và khóa API an toàn bằng EncryptedSharedPreferences (AES-256-GCM).
 * Tuyệt đối không nhúng cứng API key vào mã nguồn APK và không ghi khóa vào Logcat.
 */
class SecureConfigManager(context: Context) {

    private val appContext = context.applicationContext

    private val prefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            // Fallback an toàn trong trường hợp thiết bị Android giá rẻ bị lỗi Keystore phần cứng
            appContext.getSharedPreferences(PREFS_FALLBACK_NAME, Context.MODE_PRIVATE)
        }
    }

    fun getProviderType(): AiProviderType {
        val raw = prefs.getString(KEY_PROVIDER_TYPE, AiProviderType.BACKEND_PROXY.name)
        return runCatching { AiProviderType.valueOf(raw ?: AiProviderType.BACKEND_PROXY.name) }
            .getOrDefault(AiProviderType.BACKEND_PROXY)
    }

    fun getEndpointUrl(): String {
        val provider = getProviderType()
        return prefs.getString(KEY_ENDPOINT_URL, provider.defaultEndpoint)?.trim()
            .takeUnless { it.isNullOrEmpty() } ?: provider.defaultEndpoint
    }

    fun getModelName(): String {
        val provider = getProviderType()
        return prefs.getString(KEY_MODEL_NAME, provider.defaultModel)?.trim()
            .takeUnless { it.isNullOrEmpty() } ?: provider.defaultModel
    }

    fun getApiKey(): String {
        return prefs.getString(KEY_API_SECRET, "")?.trim() ?: ""
    }

    fun saveAiConfiguration(
        providerType: AiProviderType,
        endpointUrl: String,
        modelName: String,
        apiKey: String
    ) {
        prefs.edit()
            .putString(KEY_PROVIDER_TYPE, providerType.name)
            .putString(KEY_ENDPOINT_URL, endpointUrl.trim())
            .putString(KEY_MODEL_NAME, modelName.trim())
            .putString(KEY_API_SECRET, apiKey.trim())
            .apply()
    }

    /**
     * Kiểm tra xem người dùng đã cấu hình hợp lệ chưa.
     * Nếu chưa có API key (đối với Gemini/OpenAI) hoặc chưa đổi URL ví dụ của Backend Proxy,
     * ứng dụng sẽ thông báo rõ thay vì giả vờ đã kết nối AI.
     */
    fun isConfiguredReady(): Boolean {
        val provider = getProviderType()
        val endpoint = getEndpointUrl()
        val key = getApiKey()
        return when (provider) {
            AiProviderType.BACKEND_PROXY -> {
                endpoint.startsWith("https://") &&
                    !endpoint.contains("your-studyai-proxy.example.com")
            }
            AiProviderType.GOOGLE_GEMINI, AiProviderType.OPENAI_COMPATIBLE -> {
                endpoint.startsWith("https://") && key.length >= 12
            }
        }
    }

    fun getSavedNightMode(): Int {
        return prefs.getInt(KEY_NIGHT_MODE, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }

    fun toggleNightMode(): Int {
        val current = getSavedNightMode()
        val next = if (current == AppCompatDelegate.MODE_NIGHT_YES) {
            AppCompatDelegate.MODE_NIGHT_NO
        } else {
            AppCompatDelegate.MODE_NIGHT_YES
        }
        prefs.edit().putInt(KEY_NIGHT_MODE, next).apply()
        AppCompatDelegate.setDefaultNightMode(next)
        return next
    }

    fun clearAllPersonalAndConfigData() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val PREFS_FILE_NAME = "studyai_secure_prefs"
        private const val PREFS_FALLBACK_NAME = "studyai_fallback_prefs"
        private const val KEY_PROVIDER_TYPE = "ai_provider_type"
        private const val KEY_ENDPOINT_URL = "ai_endpoint_url"
        private const val KEY_MODEL_NAME = "ai_model_name"
        private const val KEY_API_SECRET = "ai_api_secret_key"
        private const val KEY_NIGHT_MODE = "ui_night_mode"

        /**
         * Ẩn mọi khóa API, Bearer Token hoặc chuỗi nhạy cảm khỏi thông báo lỗi và Log.
         */
        fun sanitizeSensitiveErrorMessage(rawMessage: String?, currentSecret: String = ""): String {
            if (rawMessage.isNullOrBlank()) return "Lỗi không xác định khi kết nối dịch vụ."
            var sanitized = rawMessage
            if (currentSecret.length >= 6) {
                sanitized = sanitized.replace(currentSecret, "***[API_KEY_REDACTED]***")
            }
            // Che các tham số ?key=... và chuỗi AIza... / sk-...
            sanitized = sanitized.replace(Regex("key=[A-Za-z0-9_\-]{8,}"), "key=***REDACTED***")
            sanitized = sanitized.replace(Regex("AIza[0-9A-Za-z_\-]{15,}"), "AIza***REDACTED***")
            sanitized = sanitized.replace(Regex("sk-[0-9A-Za-z_\-]{12,}"), "sk-***REDACTED***")
            sanitized = sanitized.replace(Regex("Bearer\s+[A-Za-z0-9._\-]+"), "Bearer ***REDACTED***")
            return sanitized
        }
    }
}
