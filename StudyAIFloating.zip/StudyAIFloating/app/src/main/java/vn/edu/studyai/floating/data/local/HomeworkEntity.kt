package vn.edu.studyai.floating.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import vn.edu.studyai.floating.model.StructuredSolution

@Entity(tableName = "homework_history")
data class HomeworkEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val subjectName: String,
    val questionType: String,
    val recognizedProblem: String,
    val requiredKnowledge: String,
    val stepByStepSolution: String,
    val finalAnswer: String,
    val verification: String,
    val simplifiedExplanation: String,
    val createdAtEpochMs: Long = System.currentTimeMillis()
) {
    fun toStructuredSolution(): StructuredSolution {
        return StructuredSolution(
            recognizedProblem = recognizedProblem,
            requiredKnowledge = requiredKnowledge,
            stepByStepSolution = stepByStepSolution,
            finalAnswer = finalAnswer,
            verification = verification,
            simplifiedExplanation = simplifiedExplanation
        )
    }
}
