package vn.edu.studyai.floating

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import vn.edu.studyai.floating.ai.AiPromptBuilder
import vn.edu.studyai.floating.ai.AiResponseParser
import vn.edu.studyai.floating.model.QuestionType
import vn.edu.studyai.floating.model.SchoolSubject
import vn.edu.studyai.floating.ocr.BitmapMemoryOptimizer
import vn.edu.studyai.floating.ocr.OcrProcessor
import vn.edu.studyai.floating.security.SecureConfigManager

class StudyAiCoreLogicTest {

    @Test
    fun testAllTenSubjectsPresent() {
        val subjects = SchoolSubject.entries
        assertEquals(10, subjects.size)
        assertEquals(SchoolSubject.MATH, SchoolSubject.fromDisplayName("Toán"))
        assertEquals(SchoolSubject.ECON_LAW, SchoolSubject.fromDisplayName("Giáo dục kinh tế và pháp luật"))
    }

    @Test
    fun testInputValidationRejectsEmptyOrTooShortInput() {
        assertNotNull(AiPromptBuilder.validateInputBeforeSending("   "))
        assertNotNull(AiPromptBuilder.validateInputBeforeSending("1+"))
        assertNull(AiPromptBuilder.validateInputBeforeSending("Giải phương trình x^2 - 5x + 6 = 0"))
    }

    @Test
    fun testStructuredJsonParsingSixSections() {
        val sampleAiJson = """
        {
          "recognizedProblem": "Giải phương trình bậc hai: x^2 - 5x + 6 = 0",
          "requiredKnowledge": "Công thức nghiệm phương trình bậc hai ax^2 + bx + c = 0: \\Delta = b^2 - 4ac",
          "stepByStepSolution": "Bước 1: Tính \\Delta = (-5)^2 - 4.1.6 = 25 - 24 = 1 > 0.\nBước 2: Phương trình có 2 nghiệm phân biệt x1 = (5 - \\sqrt{1})/2 = 2; x2 = (5 + \\sqrt{1})/2 = 3.",
          "finalAnswer": "x = 2 hoặc x = 3",
          "verification": "Thay x = 2: 2^2 - 5(2) + 6 = 0 (đúng). Thay x = 3: 3^2 - 5(3) + 6 = 0 (đúng).",
          "simplifiedExplanation": "Nhẩm nghiệm nhanh theo Vi-ét: tổng 2 nghiệm bằng 5, tích 2 nghiệm bằng 6 nên hai số đó là 2 và 3.",
          "needsClarification": false,
          "clarificationReason": ""
        }
        """.trimIndent()

        val parsed = AiResponseParser.parseAiTextToStructuredSolution(
            sampleAiJson,
            "x^2 - 5x + 6 = 0"
        )
        assertFalse(parsed.needsClarification)
        assertEquals("x = 2 hoặc x = 3", parsed.finalAnswer)
        assertTrue(parsed.requiredKnowledge.contains("Δ"))
        assertTrue(parsed.stepByStepSolution.contains("√"))
    }

    @Test
    fun testAntiHallucinationWhenNeedsClarificationIsTrue() {
        val blurryJson = """
        {
          "recognizedProblem": "Cho tam giác ABC có AB = ...",
          "requiredKnowledge": "",
          "stepByStepSolution": "",
          "finalAnswer": "",
          "verification": "",
          "simplifiedExplanation": "",
          "needsClarification": true,
          "clarificationReason": "Ảnh chụp bị mất góc phải nên thiếu độ dài cạnh AB và yêu cầu tính toán. Vui lòng chụp lại rõ hơn."
        }
        """.trimIndent()

        val parsed = AiResponseParser.parseAiTextToStructuredSolution(blurryJson, "Cho tam giác ABC")
        assertTrue(parsed.needsClarification)
        assertTrue(parsed.clarificationReason.contains("chụp lại"))
    }

    @Test
    fun testOcrPostProcessingVietnameseAndMathSymbols() {
        val rawOcr = "A , x >= 2   \nB : x <= -1\nFe + HCl -> FeCl2 + H2"
        val processed = OcrProcessor.postProcessVietnameseAndMathText(rawOcr)
        assertTrue(processed.contains("A. x ≥ 2"))
        assertTrue(processed.contains("B. x ≤ -1"))
        assertTrue(processed.contains("→"))
    }

    @Test
    fun testSensitiveApiKeyRedactionInLogsAndErrors() {
        val rawError = "HTTP 401 Unauthorized for https://generativelanguage.googleapis.com/v1beta?key=AIzaSyD9876543210abcdef with Bearer sk-proj1234567890abcdef"
        val sanitized = SecureConfigManager.sanitizeSensitiveErrorMessage(rawError, "AIzaSyD9876543210abcdef")
        assertFalse(sanitized.contains("AIzaSyD9876543210abcdef"))
        assertFalse(sanitized.contains("sk-proj1234567890abcdef"))
        assertTrue(sanitized.contains("REDACTED"))
    }

    @Test
    fun testBitmapMemoryOptimizerDownsamplingForOppoA18() {
        // Ảnh chụp camera 12MP (4000x3000) phải được giảm kích thước (inSampleSize >= 2) để tránh tràn RAM 4GB
        val sampleSize = BitmapMemoryOptimizer.calculateInSampleSize(4000, 3000, 1280)
        assertTrue(sampleSize >= 2)
    }
}
